"use client"

import { useState, useEffect } from "react"
import { ChevronLeft, ChevronRight, BookOpen, Settings, Bookmark, Share2, Download, Menu } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Slider } from "@/components/ui/slider"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Progress } from "@/components/ui/progress"
import Link from "next/link"

const bookData = {
  id: 1,
  title: "Lập trình Python cơ bản",
  author: "Nguyễn Văn A",
  totalPages: 320,
  currentPage: 1,
}

export default function BookReader() {
  const [currentPage, setCurrentPage] = useState(1)
  const [zoom, setZoom] = useState(100)
  const [isDarkMode, setIsDarkMode] = useState(false)
  const [fontSize, setFontSize] = useState(16)
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [readingProgress, setReadingProgress] = useState(0)
  const [bookmarks, setBookmarks] = useState<number[]>([])
  const [isBookmarked, setIsBookmarked] = useState(false)

  useEffect(() => {
    const progress = (currentPage / bookData.totalPages) * 100
    setReadingProgress(progress)
    setIsBookmarked(bookmarks.includes(currentPage))
  }, [currentPage, bookmarks])

  const nextPage = () => {
    if (currentPage < bookData.totalPages) {
      setCurrentPage(currentPage + 1)
    }
  }

  const prevPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1)
    }
  }

  const toggleBookmark = () => {
    if (isBookmarked) {
      setBookmarks(bookmarks.filter((page) => page !== currentPage))
    } else {
      setBookmarks([...bookmarks, currentPage])
    }
  }

  const goToPage = (page: number) => {
    if (page >= 1 && page <= bookData.totalPages) {
      setCurrentPage(page)
    }
  }

  return (
    <div className={`min-h-screen ${isDarkMode ? "bg-gray-900 text-white" : "bg-gray-100 text-gray-900"}`}>
      {/* Header */}
      <header className={`${isDarkMode ? "bg-gray-800" : "bg-white"} shadow-sm border-b sticky top-0 z-50`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <Link href="/books" className="flex items-center space-x-2">
                <BookOpen className="h-6 w-6 text-blue-600" />
                <span className="font-semibold">Thư viện số</span>
              </Link>
              <div className="hidden md:block">
                <h1 className="text-lg font-medium truncate max-w-md">{bookData.title}</h1>
                <p className="text-sm text-gray-500">Tác giả: {bookData.author}</p>
              </div>
            </div>

            <div className="flex items-center space-x-2">
              {/* Progress */}
              <div className="hidden md:flex items-center space-x-2 min-w-32">
                <span className="text-sm">{Math.round(readingProgress)}%</span>
                <Progress value={readingProgress} className="w-20" />
              </div>

              {/* Page Navigation */}
              <div className="flex items-center space-x-2">
                <Button variant="outline" size="sm" onClick={prevPage} disabled={currentPage === 1}>
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <span className="text-sm min-w-20 text-center">
                  {currentPage} / {bookData.totalPages}
                </span>
                <Button variant="outline" size="sm" onClick={nextPage} disabled={currentPage === bookData.totalPages}>
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>

              {/* Tools */}
              <div className="flex items-center space-x-2">
                <Button variant="outline" size="sm" onClick={toggleBookmark}>
                  <Bookmark className={`h-4 w-4 ${isBookmarked ? "fill-current text-yellow-500" : ""}`} />
                </Button>

                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" size="sm">
                      <Settings className="h-4 w-4" />
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-80">
                    <div className="space-y-4">
                      <h4 className="font-medium">Cài đặt đọc sách</h4>

                      {/* Dark Mode */}
                      <div className="flex items-center justify-between">
                        <Label htmlFor="dark-mode">Chế độ tối</Label>
                        <Switch id="dark-mode" checked={isDarkMode} onCheckedChange={setIsDarkMode} />
                      </div>

                      {/* Font Size */}
                      <div className="space-y-2">
                        <Label>Cỡ chữ: {fontSize}px</Label>
                        <Slider
                          value={[fontSize]}
                          onValueChange={(value) => setFontSize(value[0])}
                          max={24}
                          min={12}
                          step={1}
                        />
                      </div>

                      {/* Zoom */}
                      <div className="space-y-2">
                        <Label>Zoom: {zoom}%</Label>
                        <Slider
                          value={[zoom]}
                          onValueChange={(value) => setZoom(value[0])}
                          max={200}
                          min={50}
                          step={10}
                        />
                      </div>

                      {/* Page Layout */}
                      <div className="space-y-2">
                        <Label>Bố cục trang</Label>
                        <Select defaultValue="single">
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="single">Trang đơn</SelectItem>
                            <SelectItem value="double">Trang đôi</SelectItem>
                            <SelectItem value="scroll">Cuộn liên tục</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </PopoverContent>
                </Popover>

                <Button variant="outline" size="sm">
                  <Share2 className="h-4 w-4" />
                </Button>

                <Button variant="outline" size="sm">
                  <Download className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="flex h-[calc(100vh-4rem)]">
        {/* Sidebar */}
        <div
          className={`${isMenuOpen ? "w-80" : "w-0"} transition-all duration-300 overflow-hidden ${isDarkMode ? "bg-gray-800" : "bg-white"} border-r`}
        >
          <div className="p-4 space-y-4">
            <h3 className="font-semibold">Mục lục</h3>
            <div className="space-y-2 max-h-96 overflow-y-auto">
              {[
                { title: "Chương 1: Giới thiệu", page: 1 },
                { title: "Chương 2: Cú pháp cơ bản", page: 25 },
                { title: "Chương 3: Cấu trúc dữ liệu", page: 50 },
                { title: "Chương 4: Hàm và Module", page: 85 },
                { title: "Chương 5: OOP", page: 120 },
                { title: "Chương 6: File và Exception", page: 160 },
                { title: "Chương 7: Thư viện", page: 200 },
                { title: "Chương 8: Dự án", page: 250 },
              ].map((chapter, index) => (
                <button
                  key={index}
                  onClick={() => goToPage(chapter.page)}
                  className={`w-full text-left p-2 rounded hover:bg-gray-100 ${isDarkMode ? "hover:bg-gray-700" : ""} ${
                    currentPage >= chapter.page ? "text-blue-600" : ""
                  }`}
                >
                  <div className="text-sm font-medium">{chapter.title}</div>
                  <div className="text-xs text-gray-500">Trang {chapter.page}</div>
                </button>
              ))}
            </div>

            {bookmarks.length > 0 && (
              <>
                <h3 className="font-semibold mt-6">Bookmark</h3>
                <div className="space-y-2">
                  {bookmarks.map((page) => (
                    <button
                      key={page}
                      onClick={() => goToPage(page)}
                      className={`w-full text-left p-2 rounded hover:bg-gray-100 ${isDarkMode ? "hover:bg-gray-700" : ""}`}
                    >
                      <div className="text-sm">Trang {page}</div>
                    </button>
                  ))}
                </div>
              </>
            )}
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 flex flex-col">
          {/* Toggle Sidebar Button */}
          <Button
            variant="outline"
            size="sm"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="absolute top-20 left-4 z-40"
          >
            <Menu className="h-4 w-4" />
          </Button>

          {/* PDF Viewer */}
          <div className="flex-1 flex items-center justify-center p-4">
            <Card className="w-full max-w-4xl h-full">
              <CardContent className="p-0 h-full flex items-center justify-center">
                <div
                  className={`w-full h-full flex items-center justify-center ${isDarkMode ? "bg-gray-800" : "bg-white"}`}
                  style={{ transform: `scale(${zoom / 100})` }}
                >
                  {/* Simulated PDF Page */}
                  <div
                    className={`w-full max-w-2xl h-full p-8 ${isDarkMode ? "bg-gray-700 text-white" : "bg-white text-gray-900"} shadow-lg`}
                  >
                    <div style={{ fontSize: `${fontSize}px`, lineHeight: 1.6 }}>
                      <h1 className="text-2xl font-bold mb-6">
                        Chương {Math.ceil(currentPage / 40)}: Nội dung trang {currentPage}
                      </h1>
                      <p className="mb-4">
                        Đây là nội dung mô phỏng của trang {currentPage} trong cuốn sách "{bookData.title}". Trong thực
                        tế, đây sẽ là nội dung PDF được render bởi thư viện như PDF.js hoặc React-PDF.
                      </p>
                      <p className="mb-4">
                        Bạn có thể điều chỉnh cỡ chữ, zoom, chế độ tối/sáng và nhiều tùy chọn khác từ menu cài đặt. Hệ
                        thống cũng hỗ trợ bookmark để đánh dấu các trang quan trọng.
                      </p>
                      <p className="mb-4">
                        Tiến độ đọc của bạn được lưu tự động và bạn có thể tiếp tục từ vị trí đã dừng lại.
                      </p>

                      {/* Simulated content based on page */}
                      {currentPage <= 40 && (
                        <div>
                          <h2 className="text-xl font-semibold mb-3">1. Giới thiệu về Python</h2>
                          <p>
                            Python là một ngôn ngữ lập trình bậc cao, được thiết kế với triết lý đơn giản và dễ đọc...
                          </p>
                        </div>
                      )}

                      {currentPage > 40 && currentPage <= 80 && (
                        <div>
                          <h2 className="text-xl font-semibold mb-3">2. Cú pháp cơ bản</h2>
                          <p>Cú pháp Python được thiết kế để dễ đọc và viết. Không giống như nhiều ngôn ngữ khác...</p>
                          <pre className={`${isDarkMode ? "bg-gray-800" : "bg-gray-100"} p-3 rounded mt-3`}>
                            {`print("Hello, World!")
x = 10
y = 20
print(x + y)`}
                          </pre>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Bottom Navigation */}
          <div className={`${isDarkMode ? "bg-gray-800" : "bg-white"} border-t p-4`}>
            <div className="flex items-center justify-between max-w-4xl mx-auto">
              <Button variant="outline" onClick={prevPage} disabled={currentPage === 1}>
                <ChevronLeft className="h-4 w-4 mr-2" />
                Trang trước
              </Button>

              <div className="flex items-center space-x-4">
                <input
                  type="number"
                  value={currentPage}
                  onChange={(e) => goToPage(Number.parseInt(e.target.value) || 1)}
                  className={`w-16 text-center border rounded px-2 py-1 ${isDarkMode ? "bg-gray-700 border-gray-600" : "bg-white border-gray-300"}`}
                  min="1"
                  max={bookData.totalPages}
                />
                <span>/ {bookData.totalPages}</span>
              </div>

              <Button variant="outline" onClick={nextPage} disabled={currentPage === bookData.totalPages}>
                Trang sau
                <ChevronRight className="h-4 w-4 ml-2" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
