"use client"

import { useState } from "react"
import { Search, BookOpen, Download, Star } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"

const featuredBooks = [
  {
    id: 1,
    title: "Lập trình Python cơ bản",
    author: "Nguyễn Văn A",
    category: "Công nghệ",
    rating: 4.8,
    downloads: 1250,
    cover: "/placeholder.svg?height=200&width=150",
    description: "Hướng dẫn học Python từ cơ bản đến nâng cao",
  },
  {
    id: 2,
    title: "Kinh tế học vi mô",
    author: "Trần Thị B",
    category: "Kinh tế",
    rating: 4.6,
    downloads: 890,
    cover: "/placeholder.svg?height=200&width=150",
    description: "Giáo trình kinh tế học vi mô dành cho sinh viên",
  },
  {
    id: 3,
    title: "Văn học Việt Nam hiện đại",
    author: "Lê Văn C",
    category: "Văn học",
    rating: 4.9,
    downloads: 2100,
    cover: "/placeholder.svg?height=200&width=150",
    description: "Tổng quan về văn học Việt Nam thế kỷ 20",
  },
  {
    id: 4,
    title: "Toán cao cấp A1",
    author: "Phạm Thị D",
    category: "Toán học",
    rating: 4.7,
    downloads: 1680,
    cover: "/placeholder.svg?height=200&width=150",
    description: "Giáo trình toán cao cấp cho sinh viên kỹ thuật",
  },
]

const categories = [
  { name: "Công nghệ", count: 245, icon: "💻" },
  { name: "Kinh tế", count: 189, icon: "📈" },
  { name: "Văn học", count: 156, icon: "📚" },
  { name: "Toán học", count: 134, icon: "🔢" },
  { name: "Khoa học", count: 98, icon: "🔬" },
  { name: "Lịch sử", count: 87, icon: "📜" },
]

export default function HomePage() {
  const [searchQuery, setSearchQuery] = useState("")

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2">
              <BookOpen className="h-8 w-8 text-blue-600" />
              <h1 className="text-2xl font-bold text-gray-900">Thư viện số</h1>
            </div>
            <nav className="hidden md:flex space-x-8">
              <Link href="/" className="text-gray-700 hover:text-blue-600">
                Trang chủ
              </Link>
              <Link href="/books" className="text-gray-700 hover:text-blue-600">
                Sách
              </Link>
              <Link href="/categories" className="text-gray-700 hover:text-blue-600">
                Danh mục
              </Link>
              <Link href="/about" className="text-gray-700 hover:text-blue-600">
                Giới thiệu
              </Link>
            </nav>
            <div className="flex items-center space-x-4">
              <Button variant="outline">Đăng nhập</Button>
              <Button>Đăng ký</Button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
            Khám phá tri thức
            <span className="text-blue-600"> không giới hạn</span>
          </h2>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            Truy cập hàng nghìn tài liệu, sách điện tử và nghiên cứu khoa học từ thư viện số hàng đầu Việt Nam
          </p>

          {/* Search Bar */}
          <div className="max-w-2xl mx-auto mb-12">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
              <Input
                type="text"
                placeholder="Tìm kiếm sách, tác giả, chủ đề..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-12 pr-4 py-4 text-lg rounded-full border-2 border-gray-200 focus:border-blue-500"
              />
              <Button className="absolute right-2 top-1/2 transform -translate-y-1/2 rounded-full">Tìm kiếm</Button>
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600 mb-2">10,000+</div>
              <div className="text-gray-600">Tài liệu</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-green-600 mb-2">50,000+</div>
              <div className="text-gray-600">Người dùng</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-purple-600 mb-2">100+</div>
              <div className="text-gray-600">Chuyên ngành</div>
            </div>
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h3 className="text-3xl font-bold text-center text-gray-900 mb-12">Danh mục phổ biến</h3>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
            {categories.map((category, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow cursor-pointer">
                <CardContent className="p-6 text-center">
                  <div className="text-4xl mb-4">{category.icon}</div>
                  <h4 className="font-semibold text-gray-900 mb-2">{category.name}</h4>
                  <p className="text-sm text-gray-600">{category.count} tài liệu</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Books */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-12">
            <h3 className="text-3xl font-bold text-gray-900">Sách nổi bật</h3>
            <Button variant="outline">Xem tất cả</Button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {featuredBooks.map((book) => (
              <Card key={book.id} className="hover:shadow-xl transition-shadow">
                <CardHeader className="p-0">
                  <img
                    src={book.cover || "/placeholder.svg"}
                    alt={book.title}
                    className="w-full h-48 object-cover rounded-t-lg"
                  />
                </CardHeader>
                <CardContent className="p-6">
                  <Badge className="mb-2">{book.category}</Badge>
                  <CardTitle className="text-lg mb-2 line-clamp-2">{book.title}</CardTitle>
                  <CardDescription className="mb-3">Tác giả: {book.author}</CardDescription>
                  <p className="text-sm text-gray-600 mb-4 line-clamp-2">{book.description}</p>
                  <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
                    <div className="flex items-center">
                      <Star className="h-4 w-4 text-yellow-400 mr-1" />
                      {book.rating}
                    </div>
                    <div className="flex items-center">
                      <Download className="h-4 w-4 mr-1" />
                      {book.downloads}
                    </div>
                  </div>
                  <Button className="w-full">Đọc ngay</Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <BookOpen className="h-8 w-8" />
                <h3 className="text-xl font-bold">Thư viện số</h3>
              </div>
              <p className="text-gray-400">Nền tảng thư viện số hàng đầu Việt Nam, cung cấp tri thức cho mọi người.</p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Liên kết</h4>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Link href="/books">Sách</Link>
                </li>
                <li>
                  <Link href="/categories">Danh mục</Link>
                </li>
                <li>
                  <Link href="/authors">Tác giả</Link>
                </li>
                <li>
                  <Link href="/new-releases">Mới phát hành</Link>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Hỗ trợ</h4>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Link href="/help">Trợ giúp</Link>
                </li>
                <li>
                  <Link href="/contact">Liên hệ</Link>
                </li>
                <li>
                  <Link href="/faq">FAQ</Link>
                </li>
                <li>
                  <Link href="/terms">Điều khoản</Link>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Theo dõi chúng tôi</h4>
              <div className="flex space-x-4">
                <Button variant="outline" size="sm">
                  Facebook
                </Button>
                <Button variant="outline" size="sm">
                  Twitter
                </Button>
                <Button variant="outline" size="sm">
                  LinkedIn
                </Button>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 Thư viện số. Tất cả quyền được bảo lưu.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
