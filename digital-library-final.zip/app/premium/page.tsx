"use client"

import { useState } from "react"
import { Check, Crown, Star, BookOpen, Users, Download, Shield } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import Link from "next/link"

const plans = [
  {
    name: "Cơ bản",
    price: "Miễn phí",
    monthlyPrice: 0,
    yearlyPrice: 0,
    description: "Dành cho người mới bắt đầu",
    features: [
      "Truy cập 1,000+ sách miễn phí",
      "Đọc online cơ bản",
      "Tìm kiếm và lọc",
      "Bookmark cơ bản",
      "Hỗ trợ email",
    ],
    limitations: ["Không tải về", "Có quảng cáo", "Giới hạn 5 bookmark"],
    popular: false,
    color: "border-gray-200",
  },
  {
    name: "Premium",
    price: "99,000₫",
    monthlyPrice: 99000,
    yearlyPrice: 990000,
    description: "Dành cho người đọc thường xuyên",
    features: [
      "Tất cả tính năng Cơ bản",
      "Truy cập 5,000+ sách premium",
      "Tải về PDF không giới hạn",
      "Đọc offline",
      "Không quảng cáo",
      "Bookmark không giới hạn",
      "Ghi chú và highlight",
      "Đồng bộ đa thiết bị",
      "Hỗ trợ ưu tiên",
    ],
    limitations: [],
    popular: true,
    color: "border-blue-500",
  },
  {
    name: "Pro",
    price: "199,000₫",
    monthlyPrice: 199000,
    yearlyPrice: 1990000,
    description: "Dành cho chuyên gia và tổ chức",
    features: [
      "Tất cả tính năng Premium",
      "Truy cập toàn bộ thư viện",
      "Sách độc quyền và mới nhất",
      "Audiobook premium",
      "Khóa học online",
      "Webinar và workshop",
      "Tư vấn 1-1 với chuyên gia",
      "API access",
      "Báo cáo chi tiết",
      "Hỗ trợ 24/7",
    ],
    limitations: [],
    popular: false,
    color: "border-purple-500",
  },
]

const premiumBooks = [
  {
    id: 1,
    title: "Advanced Python Programming",
    author: "John Smith",
    rating: 4.9,
    price: "Premium",
    cover: "/placeholder.svg?height=200&width=150",
    category: "Công nghệ",
  },
  {
    id: 2,
    title: "Financial Analysis Masterclass",
    author: "Jane Doe",
    rating: 4.8,
    price: "Premium",
    cover: "/placeholder.svg?height=200&width=150",
    category: "Kinh tế",
  },
  {
    id: 3,
    title: "Modern Literature Collection",
    author: "Various Authors",
    rating: 4.7,
    price: "Pro",
    cover: "/placeholder.svg?height=200&width=150",
    category: "Văn học",
  },
]

export default function PremiumPage() {
  const [isYearly, setIsYearly] = useState(false)
  const [selectedPlan, setSelectedPlan] = useState("premium")

  const handleSubscribe = (planName: string) => {
    // Redirect to payment gateway
    console.log(`Subscribing to ${planName} plan`)
    // In real app, integrate with Stripe, PayPal, or local payment gateway
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Link href="/" className="flex items-center space-x-2">
              <BookOpen className="h-8 w-8 text-blue-600" />
              <h1 className="text-2xl font-bold text-gray-900">Thư viện số</h1>
            </Link>
            <nav className="hidden md:flex space-x-8">
              <Link href="/" className="text-gray-700 hover:text-blue-600">
                Trang chủ
              </Link>
              <Link href="/books" className="text-gray-700 hover:text-blue-600">
                Sách
              </Link>
              <Link href="/premium" className="text-blue-600 font-medium">
                Premium
              </Link>
            </nav>
            <div className="flex items-center space-x-4">
              <Button variant="outline">Đăng nhập</Button>
              <Button>Đăng ký</Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Hero Section */}
        <div className="text-center mb-16">
          <div className="flex items-center justify-center mb-4">
            <Crown className="h-12 w-12 text-yellow-500 mr-3" />
            <h1 className="text-4xl md:text-6xl font-bold text-gray-900">Nâng cấp Premium</h1>
          </div>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            Mở khóa toàn bộ thư viện với hàng nghìn sách premium, tính năng nâng cao và trải nghiệm đọc tuyệt vời
          </p>

          {/* Billing Toggle */}
          <div className="flex items-center justify-center space-x-4 mb-8">
            <Label htmlFor="billing-toggle" className={!isYearly ? "font-semibold" : ""}>
              Hàng tháng
            </Label>
            <Switch id="billing-toggle" checked={isYearly} onCheckedChange={setIsYearly} />
            <Label htmlFor="billing-toggle" className={isYearly ? "font-semibold" : ""}>
              Hàng năm
              <Badge className="ml-2 bg-green-100 text-green-800">Tiết kiệm 20%</Badge>
            </Label>
          </div>
        </div>

        {/* Pricing Plans */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          {plans.map((plan, index) => (
            <Card key={index} className={`relative ${plan.color} ${plan.popular ? "ring-2 ring-blue-500" : ""}`}>
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <Badge className="bg-blue-500 text-white px-4 py-1">Phổ biến nhất</Badge>
                </div>
              )}
              <CardHeader className="text-center pb-4">
                <CardTitle className="text-2xl font-bold">{plan.name}</CardTitle>
                <CardDescription>{plan.description}</CardDescription>
                <div className="mt-4">
                  <div className="text-4xl font-bold text-gray-900">
                    {plan.monthlyPrice === 0
                      ? "Miễn phí"
                      : isYearly
                        ? `${(plan.yearlyPrice / 12).toLocaleString()}₫`
                        : `${plan.monthlyPrice.toLocaleString()}₫`}
                  </div>
                  {plan.monthlyPrice > 0 && (
                    <div className="text-sm text-gray-500">
                      {isYearly ? "/ tháng (thanh toán hàng năm)" : "/ tháng"}
                    </div>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3 mb-6">
                  {plan.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center">
                      <Check className="h-5 w-5 text-green-500 mr-3 flex-shrink-0" />
                      <span className="text-sm">{feature}</span>
                    </li>
                  ))}
                </ul>

                {plan.limitations.length > 0 && (
                  <div className="mb-6">
                    <p className="text-sm font-medium text-gray-700 mb-2">Giới hạn:</p>
                    <ul className="space-y-1">
                      {plan.limitations.map((limitation, limitIndex) => (
                        <li key={limitIndex} className="text-sm text-gray-500">
                          • {limitation}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                <Button
                  className="w-full"
                  variant={plan.popular ? "default" : "outline"}
                  onClick={() => handleSubscribe(plan.name.toLowerCase())}
                  disabled={plan.monthlyPrice === 0}
                >
                  {plan.monthlyPrice === 0 ? "Gói hiện tại" : "Chọn gói này"}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Premium Features */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">Tại sao chọn Premium?</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="bg-blue-100 rounded-full p-4 w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                <BookOpen className="h-8 w-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Thư viện khổng lồ</h3>
              <p className="text-gray-600">Truy cập hơn 10,000 sách và tài liệu chất lượng cao</p>
            </div>
            <div className="text-center">
              <div className="bg-green-100 rounded-full p-4 w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                <Download className="h-8 w-8 text-green-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Tải về không giới hạn</h3>
              <p className="text-gray-600">Đọc offline mọi lúc mọi nơi với file PDF chất lượng cao</p>
            </div>
            <div className="text-center">
              <div className="bg-purple-100 rounded-full p-4 w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                <Users className="h-8 w-8 text-purple-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Cộng đồng độc giả</h3>
              <p className="text-gray-600">Kết nối với hàng nghìn độc giả và chia sẻ kinh nghiệm</p>
            </div>
            <div className="text-center">
              <div className="bg-orange-100 rounded-full p-4 w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                <Shield className="h-8 w-8 text-orange-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Hỗ trợ ưu tiên</h3>
              <p className="text-gray-600">Được hỗ trợ 24/7 từ đội ngũ chuyên nghiệp</p>
            </div>
          </div>
        </div>

        {/* Premium Books Preview */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">Sách Premium nổi bật</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {premiumBooks.map((book) => (
              <Card key={book.id} className="hover:shadow-lg transition-shadow">
                <CardHeader className="p-0">
                  <img
                    src={book.cover || "/placeholder.svg"}
                    alt={book.title}
                    className="w-full h-48 object-cover rounded-t-lg"
                  />
                </CardHeader>
                <CardContent className="p-6">
                  <Badge className="mb-2">{book.category}</Badge>
                  <CardTitle className="text-lg mb-2">{book.title}</CardTitle>
                  <CardDescription className="mb-3">Tác giả: {book.author}</CardDescription>
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center">
                      <Star className="h-4 w-4 text-yellow-400 mr-1" />
                      {book.rating}
                    </div>
                    <Badge variant="secondary">
                      <Crown className="h-3 w-3 mr-1" />
                      {book.price}
                    </Badge>
                  </div>
                  <Button className="w-full" disabled>
                    Cần Premium để đọc
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* FAQ */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">Câu hỏi thường gặp</h2>
          <div className="max-w-3xl mx-auto space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Tôi có thể hủy đăng ký bất cứ lúc nào không?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Có, bạn có thể hủy đăng ký Premium bất cứ lúc nào. Bạn vẫn có thể sử dụng các tính năng Premium cho
                  đến hết chu kỳ thanh toán hiện tại.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Có được hoàn tiền không?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Chúng tôi cung cấp chính sách hoàn tiền trong vòng 7 ngày đầu tiên nếu bạn không hài lòng với dịch vụ
                  Premium.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Tôi có thể sử dụng Premium trên nhiều thiết bị không?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Có, tài khoản Premium của bạn có thể được sử dụng trên tối đa 5 thiết bị cùng lúc với tính năng đồng
                  bộ dữ liệu.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* CTA Section */}
        <div className="text-center bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl p-12 text-white">
          <h2 className="text-3xl font-bold mb-4">Sẵn sàng nâng cấp trải nghiệm đọc?</h2>
          <p className="text-xl mb-8 opacity-90">Tham gia cùng hàng nghìn độc giả đã chọn Premium</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" variant="secondary" onClick={() => handleSubscribe("premium")}>
              Bắt đầu với Premium
            </Button>
            <Button size="lg" variant="outline" className="text-white border-white hover:bg-white hover:text-blue-600">
              Xem demo miễn phí
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
