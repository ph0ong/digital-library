"use client"

import { useState } from "react"
import { Search, Grid, List, Star, Download, BookOpen } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import Link from "next/link"

const books = [
  {
    id: 1,
    title: "Lập trình Python cơ bản",
    author: "Nguyễn Văn A",
    category: "Công nghệ",
    rating: 4.8,
    downloads: 1250,
    pages: 320,
    year: 2023,
    cover: "/placeholder.svg?height=200&width=150",
    description: "Hướng dẫn học Python từ cơ bản đến nâng cao với các ví dụ thực tế",
  },
  {
    id: 2,
    title: "Kinh tế học vi mô",
    author: "Trần Thị B",
    category: "Kinh tế",
    rating: 4.6,
    downloads: 890,
    pages: 450,
    year: 2022,
    cover: "/placeholder.svg?height=200&width=150",
    description: "Giáo trình kinh tế học vi mô dành cho sinh viên đại học",
  },
  {
    id: 3,
    title: "Văn học Việt Nam hiện đại",
    author: "Lê Văn C",
    category: "Văn học",
    rating: 4.9,
    downloads: 2100,
    pages: 280,
    year: 2023,
    cover: "/placeholder.svg?height=200&width=150",
    description: "Tổng quan về văn học Việt Nam thế kỷ 20-21",
  },
  {
    id: 4,
    title: "Toán cao cấp A1",
    author: "Phạm Thị D",
    category: "Toán học",
    rating: 4.7,
    downloads: 1680,
    pages: 380,
    year: 2023,
    cover: "/placeholder.svg?height=200&width=150",
    description: "Giáo trình toán cao cấp cho sinh viên kỹ thuật",
  },
  {
    id: 5,
    title: "Hóa học đại cương",
    author: "Hoàng Văn E",
    category: "Khoa học",
    rating: 4.5,
    downloads: 750,
    pages: 420,
    year: 2022,
    cover: "/placeholder.svg?height=200&width=150",
    description: "Kiến thức cơ bản về hóa học cho sinh viên năm nhất",
  },
  {
    id: 6,
    title: "Lịch sử Việt Nam",
    author: "Ngô Thị F",
    category: "Lịch sử",
    rating: 4.8,
    downloads: 1320,
    pages: 500,
    year: 2023,
    cover: "/placeholder.svg?height=200&width=150",
    description: "Lịch sử Việt Nam từ thời cổ đại đến hiện đại",
  },
]

export default function BooksPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [sortBy, setSortBy] = useState("popular")
  const [viewMode, setViewMode] = useState("grid")

  const filteredBooks = books.filter((book) => {
    const matchesSearch =
      book.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      book.author.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesCategory = selectedCategory === "all" || book.category === selectedCategory
    return matchesSearch && matchesCategory
  })

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Link href="/" className="flex items-center space-x-2">
              <BookOpen className="h-8 w-8 text-blue-600" />
              <h1 className="text-2xl font-bold text-gray-900">Thư viện số</h1>
            </Link>
            <nav className="hidden md:flex space-x-8">
              <Link href="/" className="text-gray-700 hover:text-blue-600">
                Trang chủ
              </Link>
              <Link href="/books" className="text-blue-600 font-medium">
                Sách
              </Link>
              <Link href="/categories" className="text-gray-700 hover:text-blue-600">
                Danh mục
              </Link>
              <Link href="/about" className="text-gray-700 hover:text-blue-600">
                Giới thiệu
              </Link>
            </nav>
            <div className="flex items-center space-x-4">
              <Button variant="outline">Đăng nhập</Button>
              <Button>Đăng ký</Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Page Header */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-2">Thư viện sách</h2>
          <p className="text-gray-600">Khám phá hàng nghìn tài liệu và sách điện tử</p>
        </div>

        {/* Search and Filters */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
          <div className="flex flex-col lg:flex-row gap-4">
            {/* Search */}
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                <Input
                  type="text"
                  placeholder="Tìm kiếm sách, tác giả..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>

            {/* Category Filter */}
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger className="w-full lg:w-48">
                <SelectValue placeholder="Chọn danh mục" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tất cả danh mục</SelectItem>
                <SelectItem value="Công nghệ">Công nghệ</SelectItem>
                <SelectItem value="Kinh tế">Kinh tế</SelectItem>
                <SelectItem value="Văn học">Văn học</SelectItem>
                <SelectItem value="Toán học">Toán học</SelectItem>
                <SelectItem value="Khoa học">Khoa học</SelectItem>
                <SelectItem value="Lịch sử">Lịch sử</SelectItem>
              </SelectContent>
            </Select>

            {/* Sort */}
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-full lg:w-48">
                <SelectValue placeholder="Sắp xếp theo" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="popular">Phổ biến nhất</SelectItem>
                <SelectItem value="newest">Mới nhất</SelectItem>
                <SelectItem value="rating">Đánh giá cao</SelectItem>
                <SelectItem value="title">Tên A-Z</SelectItem>
              </SelectContent>
            </Select>

            {/* View Mode */}
            <div className="flex border rounded-lg">
              <Button
                variant={viewMode === "grid" ? "default" : "ghost"}
                size="sm"
                onClick={() => setViewMode("grid")}
                className="rounded-r-none"
              >
                <Grid className="h-4 w-4" />
              </Button>
              <Button
                variant={viewMode === "list" ? "default" : "ghost"}
                size="sm"
                onClick={() => setViewMode("list")}
                className="rounded-l-none"
              >
                <List className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>

        {/* Results Count */}
        <div className="mb-6">
          <p className="text-gray-600">
            Hiển thị {filteredBooks.length} kết quả
            {searchQuery && ` cho "${searchQuery}"`}
          </p>
        </div>

        {/* Books Grid/List */}
        {viewMode === "grid" ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredBooks.map((book) => (
              <Card key={book.id} className="hover:shadow-lg transition-shadow">
                <CardHeader className="p-0">
                  <img
                    src={book.cover || "/placeholder.svg"}
                    alt={book.title}
                    className="w-full h-48 object-cover rounded-t-lg"
                  />
                </CardHeader>
                <CardContent className="p-4">
                  <Badge className="mb-2">{book.category}</Badge>
                  <CardTitle className="text-lg mb-2 line-clamp-2">{book.title}</CardTitle>
                  <CardDescription className="mb-2">Tác giả: {book.author}</CardDescription>
                  <p className="text-sm text-gray-600 mb-3 line-clamp-2">{book.description}</p>
                  <div className="flex items-center justify-between text-sm text-gray-500 mb-3">
                    <div className="flex items-center">
                      <Star className="h-4 w-4 text-yellow-400 mr-1" />
                      {book.rating}
                    </div>
                    <div className="flex items-center">
                      <Download className="h-4 w-4 mr-1" />
                      {book.downloads}
                    </div>
                  </div>
                  <div className="text-xs text-gray-500 mb-3">
                    {book.pages} trang • {book.year}
                  </div>
                  <Button className="w-full" size="sm">
                    Đọc ngay
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="space-y-4">
            {filteredBooks.map((book) => (
              <Card key={book.id} className="hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <div className="flex gap-6">
                    <img
                      src={book.cover || "/placeholder.svg"}
                      alt={book.title}
                      className="w-24 h-32 object-cover rounded-lg flex-shrink-0"
                    />
                    <div className="flex-1">
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <Badge className="mb-2">{book.category}</Badge>
                          <h3 className="text-xl font-semibold text-gray-900 mb-1">{book.title}</h3>
                          <p className="text-gray-600 mb-2">Tác giả: {book.author}</p>
                        </div>
                        <Button>Đọc ngay</Button>
                      </div>
                      <p className="text-gray-700 mb-4">{book.description}</p>
                      <div className="flex items-center gap-6 text-sm text-gray-500">
                        <div className="flex items-center">
                          <Star className="h-4 w-4 text-yellow-400 mr-1" />
                          {book.rating}
                        </div>
                        <div className="flex items-center">
                          <Download className="h-4 w-4 mr-1" />
                          {book.downloads} lượt tải
                        </div>
                        <div>{book.pages} trang</div>
                        <div>Năm {book.year}</div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* No Results */}
        {filteredBooks.length === 0 && (
          <div className="text-center py-12">
            <BookOpen className="h-16 w-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-900 mb-2">Không tìm thấy kết quả</h3>
            <p className="text-gray-600">Thử thay đổi từ khóa tìm kiếm hoặc bộ lọc</p>
          </div>
        )}
      </div>
    </div>
  )
}
