import { type NextRequest, NextResponse } from "next/server"

// Mock data - trong thực tế sẽ kết nối với database
const books = [
  {
    id: 1,
    title: "Lập trình Python cơ bản",
    author: "Nguyễn Văn A",
    category: "Công nghệ",
    rating: 4.8,
    downloads: 1250,
    pages: 320,
    year: 2023,
    publisher: "NXB Giáo dục",
    language: "Tiếng Việt",
    format: "PDF",
    size: "15.2 MB",
    cover: "/placeholder.svg?height=400&width=300",
    description: "Hướng dẫn học Python từ cơ bản đến nâng cao",
    isPremium: false,
    createdAt: "2024-01-15T00:00:00Z",
    updatedAt: "2024-01-15T00:00:00Z",
  },
  {
    id: 2,
    title: "Advanced Python Programming",
    author: "John Smith",
    category: "Công nghệ",
    rating: 4.9,
    downloads: 890,
    pages: 450,
    year: 2023,
    publisher: "Tech Publisher",
    language: "English",
    format: "PDF",
    size: "22.5 MB",
    cover: "/placeholder.svg?height=400&width=300",
    description: "Advanced Python concepts and techniques",
    isPremium: true,
    createdAt: "2024-01-10T00:00:00Z",
    updatedAt: "2024-01-10T00:00:00Z",
  },
]

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const page = Number.parseInt(searchParams.get("page") || "1")
    const limit = Number.parseInt(searchParams.get("limit") || "10")
    const category = searchParams.get("category")
    const search = searchParams.get("search")
    const isPremium = searchParams.get("premium")

    let filteredBooks = [...books]

    // Filter by category
    if (category && category !== "all") {
      filteredBooks = filteredBooks.filter((book) => book.category.toLowerCase() === category.toLowerCase())
    }

    // Filter by search query
    if (search) {
      filteredBooks = filteredBooks.filter(
        (book) =>
          book.title.toLowerCase().includes(search.toLowerCase()) ||
          book.author.toLowerCase().includes(search.toLowerCase()) ||
          book.description.toLowerCase().includes(search.toLowerCase()),
      )
    }

    // Filter by premium status
    if (isPremium !== null) {
      const premiumFilter = isPremium === "true"
      filteredBooks = filteredBooks.filter((book) => book.isPremium === premiumFilter)
    }

    // Pagination
    const startIndex = (page - 1) * limit
    const endIndex = startIndex + limit
    const paginatedBooks = filteredBooks.slice(startIndex, endIndex)

    const response = {
      success: true,
      data: {
        books: paginatedBooks,
        pagination: {
          currentPage: page,
          totalPages: Math.ceil(filteredBooks.length / limit),
          totalBooks: filteredBooks.length,
          hasNext: endIndex < filteredBooks.length,
          hasPrev: page > 1,
        },
      },
    }

    return NextResponse.json(response)
  } catch (error) {
    return NextResponse.json({ success: false, error: "Internal server error" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    // Validate required fields
    const requiredFields = ["title", "author", "category", "description"]
    for (const field of requiredFields) {
      if (!body[field]) {
        return NextResponse.json({ success: false, error: `Missing required field: ${field}` }, { status: 400 })
      }
    }

    // Create new book
    const newBook = {
      id: books.length + 1,
      title: body.title,
      author: body.author,
      category: body.category,
      description: body.description,
      pages: body.pages || 0,
      year: body.year || new Date().getFullYear(),
      publisher: body.publisher || "",
      language: body.language || "Tiếng Việt",
      format: body.format || "PDF",
      size: body.size || "0 MB",
      cover: body.cover || "/placeholder.svg?height=400&width=300",
      rating: 0,
      downloads: 0,
      isPremium: body.isPremium || false,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }

    books.push(newBook)

    return NextResponse.json(
      {
        success: true,
        data: newBook,
      },
      { status: 201 },
    )
  } catch (error) {
    return NextResponse.json({ success: false, error: "Invalid JSON data" }, { status: 400 })
  }
}
