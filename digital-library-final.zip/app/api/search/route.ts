import { type NextRequest, NextResponse } from "next/server"

// Mock search data
const searchData = {
  books: [
    { id: 1, title: "Lập trình Python cơ bản", author: "Nguyễn Văn A", type: "book" },
    { id: 2, title: "Advanced Python", author: "John Smith", type: "book" },
    { id: 3, title: "Web Development", author: "Jane Doe", type: "book" },
  ],
  authors: [
    { id: 1, name: "Nguyễn Văn A", booksCount: 5, type: "author" },
    { id: 2, name: "John Smith", booksCount: 3, type: "author" },
  ],
  categories: [
    { id: 1, name: "Công nghệ", booksCount: 245, type: "category" },
    { id: 2, name: "Kinh tế", booksCount: 189, type: "category" },
  ],
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const query = searchParams.get("q")
    const type = searchParams.get("type") // 'books', 'authors', 'categories', or 'all'
    const limit = Number.parseInt(searchParams.get("limit") || "10")

    if (!query) {
      return NextResponse.json({ success: false, error: "Search query is required" }, { status: 400 })
    }

    let results: any[] = []

    // Search in books
    if (!type || type === "all" || type === "books") {
      const bookResults = searchData.books
        .filter(
          (book) =>
            book.title.toLowerCase().includes(query.toLowerCase()) ||
            book.author.toLowerCase().includes(query.toLowerCase()),
        )
        .slice(0, limit)
      results = [...results, ...bookResults]
    }

    // Search in authors
    if (!type || type === "all" || type === "authors") {
      const authorResults = searchData.authors
        .filter((author) => author.name.toLowerCase().includes(query.toLowerCase()))
        .slice(0, limit)
      results = [...results, ...authorResults]
    }

    // Search in categories
    if (!type || type === "all" || type === "categories") {
      const categoryResults = searchData.categories
        .filter((category) => category.name.toLowerCase().includes(query.toLowerCase()))
        .slice(0, limit)
      results = [...results, ...categoryResults]
    }

    // Sort by relevance (simple implementation)
    results.sort((a, b) => {
      const aTitle = a.title || a.name
      const bTitle = b.title || b.name
      const aRelevance = aTitle.toLowerCase().indexOf(query.toLowerCase())
      const bRelevance = bTitle.toLowerCase().indexOf(query.toLowerCase())
      return aRelevance - bRelevance
    })

    return NextResponse.json({
      success: true,
      data: {
        query,
        results: results.slice(0, limit),
        totalResults: results.length,
        suggestions: ["Python programming", "Web development", "Machine learning", "Data science"].filter(
          (suggestion) => suggestion.toLowerCase().includes(query.toLowerCase()),
        ),
      },
    })
  } catch (error) {
    return NextResponse.json({ success: false, error: "Internal server error" }, { status: 500 })
  }
}
